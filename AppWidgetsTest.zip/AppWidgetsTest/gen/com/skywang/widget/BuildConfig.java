/** Automatically generated file. DO NOT MODIFY */
package com.skywang.widget;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}